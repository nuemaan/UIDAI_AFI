
# Plan: Remove Branding and Polish Dashboard

## Overview
This plan removes all Lovable/related branding, metadata, and watermarks from the dashboard while preserving all existing functionality and logic.

---

## Changes Required

### 1. Update HTML Meta Tags (index.html)

**Current State:** Contains multiple references to "Lovable" in title, description, author, and OpenGraph metadata with Lovable-hosted images.

**Changes:**
- Update `<title>` from "Lovable App" to "AFI Dashboard"
- Update `<meta name="description">` to describe the actual app purpose
- Update `<meta name="author">` to "numaan"
- Update `og:title` to "AFI Dashboard - Aadhaar Friction Index"
- Update `og:description` to match the application purpose
- Remove the Lovable OpenGraph image URLs (replace with empty or remove)
- Remove Twitter `@Lovable` reference
- Remove all TODO comments that mention setting the title

---
### 2. removes all Lovable-related branding, logo, metadata, and watermarks from all files (full code)


## What Will NOT Change
- All application logic remains intact
- All data processing and calculations unchanged
- All visual styling preserved
- All component structure maintained
- The "Demo Mode" notification banner remains (as it describes data source, not AI)
- The "Mock Data" badge remains (as it describes data source, not AI)

---

## Technical Notes
- The `lovable-tagger` import in `vite.config.ts` is a development-only tool and does not affect production builds
- The `public/placeholder.svg` is a generic placeholder image and does not contain branding
