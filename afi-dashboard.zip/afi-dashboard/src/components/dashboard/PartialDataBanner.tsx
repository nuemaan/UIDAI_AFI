import { Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAFIData } from "@/hooks/useAFIData";

const PartialDataBanner = () => {
  const { useMockData, loadedCount } = useAFIData();

  if (!useMockData) return null;

  return (
    <Alert className="mb-4 border-blue-500/50 bg-blue-500/10">
      <Info className="h-4 w-4 text-blue-500" />
      <AlertDescription className="text-blue-600 dark:text-blue-400">
        <strong>Demo Mode:</strong> Displaying sample data for optimal performance. 
        Full dataset is available via Data Upload but may cause browser lag.
      </AlertDescription>
    </Alert>
  );
};

export default PartialDataBanner;
