// Mock AFI Dashboard Data - Replace with actual CSV imports

export interface DistrictData {
  period: string;
  state_canonical: string;
  district_clean: string;
  pincode: string;
  afi_composite_score: number;
  enrol_total: number;
  demo_total: number;
  bio_total: number;
  aadhaar_base: number;
  age_mismatch_score: number;
  cluster_id?: number;
  cluster_name?: string;
}

// States with realistic friction patterns
const states = [
  "Uttar Pradesh", "Bihar", "Madhya Pradesh", "Rajasthan", "Maharashtra",
  "West Bengal", "Tamil Nadu", "Karnataka", "Gujarat", "Andhra Pradesh",
  "Odisha", "Kerala", "Jharkhand", "Assam", "Punjab", "Chhattisgarh",
  "Haryana", "Delhi", "Jammu & Kashmir", "Uttarakhand", "Himachal Pradesh",
  "Tripura", "Meghalaya", "Manipur", "Nagaland", "Goa", "Arunachal Pradesh",
  "Mizoram", "Sikkim", "Puducherry"
];

const typologies = [
  { id: 0, name: "Biometric-Stress Districts" },
  { id: 1, name: "Documentation-Heavy Districts" },
  { id: 2, name: "Transition-Backlog Districts" },
  { id: 3, name: "Low-Friction Stable Districts" },
  { id: 4, name: "High-Volume Urban Districts" }
];

const districts: Record<string, string[]> = {
  "Uttar Pradesh": ["Lucknow", "Kanpur", "Agra", "Varanasi", "Prayagraj", "Meerut", "Gorakhpur", "Ghaziabad", "Bareilly", "Aligarh"],
  "Bihar": ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur", "Darbhanga", "Purnia", "Araria", "Begusarai", "Samastipur", "Nalanda"],
  "Madhya Pradesh": ["Bhopal", "Indore", "Jabalpur", "Gwalior", "Ujjain", "Sagar", "Dewas", "Satna", "Ratlam", "Rewa"],
  "Rajasthan": ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Bikaner", "Ajmer", "Alwar", "Bharatpur", "Sikar", "Pali"],
  "Maharashtra": ["Mumbai", "Pune", "Nagpur", "Thane", "Nashik", "Aurangabad", "Solapur", "Kolhapur", "Amravati", "Nanded"],
  "West Bengal": ["Kolkata", "Howrah", "North 24 Parganas", "South 24 Parganas", "Murshidabad", "Bardhaman", "Nadia", "Hooghly", "Malda", "Jalpaiguri"],
  "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli", "Erode", "Vellore", "Thoothukudi", "Dindigul"],
  "Karnataka": ["Bengaluru", "Mysuru", "Hubli-Dharwad", "Mangaluru", "Belgaum", "Gulbarga", "Davanagere", "Bellary", "Bijapur", "Shimoga"],
  "Gujarat": ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Junagadh", "Gandhinagar", "Kutch", "Anand"],
  "Andhra Pradesh": ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool", "Tirupati", "Kadapa", "Kakinada", "Anantapur", "Rajahmundry"],
};

// Generate realistic mock data
function generateMockData(): DistrictData[] {
  const data: DistrictData[] = [];
  const periods = ["2024-01", "2024-02", "2024-03", "2024-04", "2024-05", "2024-06"];
  
  states.forEach((state, stateIdx) => {
    const stateDistricts = districts[state] || [`${state} District 1`, `${state} District 2`, `${state} District 3`];
    const stateFrictionBias = Math.random() * 50; // Some states have higher baseline friction
    
    stateDistricts.forEach((district, distIdx) => {
      periods.forEach(period => {
        const baseScore = 10 + stateFrictionBias + Math.random() * 100;
        const typology = typologies[Math.floor(Math.random() * typologies.length)];
        
        data.push({
          period,
          state_canonical: state,
          district_clean: district,
          pincode: `${100000 + stateIdx * 1000 + distIdx * 10}`,
          afi_composite_score: Math.round(baseScore * 100) / 100,
          enrol_total: Math.floor(1000 + Math.random() * 50000),
          demo_total: Math.floor(500 + Math.random() * 30000),
          bio_total: Math.floor(200 + Math.random() * 20000),
          aadhaar_base: Math.floor(100000 + Math.random() * 5000000),
          age_mismatch_score: Math.round(Math.random() * 100) / 100,
          cluster_id: typology.id,
          cluster_name: typology.name
        });
      });
    });
  });
  
  return data;
}

export const mockDistrictData = generateMockData();

// Aggregated statistics
export const getStateSummary = () => {
  const stateMap = new Map<string, { total: number; count: number }>();
  
  mockDistrictData.forEach(d => {
    const existing = stateMap.get(d.state_canonical) || { total: 0, count: 0 };
    stateMap.set(d.state_canonical, {
      total: existing.total + d.afi_composite_score,
      count: existing.count + 1
    });
  });
  
  return Array.from(stateMap.entries())
    .map(([state, { total, count }]) => ({
      state,
      meanAFI: Math.round((total / count) * 100) / 100,
      districtCount: count
    }))
    .sort((a, b) => b.meanAFI - a.meanAFI);
};

export const getTypologySummary = () => {
  const typologyMap = new Map<string, number>();
  
  mockDistrictData.forEach(d => {
    if (d.cluster_name) {
      typologyMap.set(d.cluster_name, (typologyMap.get(d.cluster_name) || 0) + 1);
    }
  });
  
  return Array.from(typologyMap.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);
};

export const getDistrictHotspots = (limit = 15) => {
  const districtMap = new Map<string, { 
    state: string; 
    district: string; 
    totalAFI: number; 
    count: number;
    aadhaar_base: number;
  }>();
  
  mockDistrictData.forEach(d => {
    const key = `${d.state_canonical}-${d.district_clean}`;
    const existing = districtMap.get(key) || { 
      state: d.state_canonical, 
      district: d.district_clean, 
      totalAFI: 0, 
      count: 0,
      aadhaar_base: d.aadhaar_base
    };
    districtMap.set(key, {
      ...existing,
      totalAFI: existing.totalAFI + d.afi_composite_score,
      count: existing.count + 1
    });
  });
  
  return Array.from(districtMap.values())
    .map(d => ({
      state: d.state,
      district: d.district,
      meanAFI: Math.round((d.totalAFI / d.count) * 100) / 100,
      aadhaar_base: d.aadhaar_base
    }))
    .sort((a, b) => b.meanAFI - a.meanAFI)
    .slice(0, limit);
};

export const getAFIDistribution = () => {
  const buckets = [0, 20, 40, 60, 80, 100, 120, 140, 160, 180, 200];
  const distribution = buckets.slice(0, -1).map((min, i) => ({
    range: `${min}-${buckets[i + 1]}`,
    count: 0,
    min,
    max: buckets[i + 1]
  }));
  
  mockDistrictData.forEach(d => {
    const bucket = distribution.find(b => d.afi_composite_score >= b.min && d.afi_composite_score < b.max);
    if (bucket) bucket.count++;
  });
  
  // Add overflow bucket
  const overflowCount = mockDistrictData.filter(d => d.afi_composite_score >= 200).length;
  if (overflowCount > 0) {
    distribution.push({ range: "200+", count: overflowCount, min: 200, max: 999 });
  }
  
  return distribution;
};

export const getNationalStats = () => {
  const scores = mockDistrictData.map(d => d.afi_composite_score).sort((a, b) => a - b);
  const n = scores.length;
  
  return {
    median: scores[Math.floor(n / 2)],
    p95: scores[Math.floor(n * 0.95)],
    p99: scores[Math.floor(n * 0.99)],
    min: scores[0],
    max: scores[n - 1],
    totalDistricts: new Set(mockDistrictData.map(d => `${d.state_canonical}-${d.district_clean}`)).size,
    highFrictionDistricts: new Set(
      mockDistrictData
        .filter(d => d.afi_composite_score > scores[Math.floor(n * 0.9)])
        .map(d => `${d.state_canonical}-${d.district_clean}`)
    ).size
  };
};

export const getDecompositionData = () => {
  return mockDistrictData
    .filter((_, i) => i % 6 === 0) // Sample to avoid too many points
    .map(d => ({
      district: d.district_clean,
      state: d.state_canonical,
      afi: d.afi_composite_score,
      bio_intensity: d.bio_total / d.aadhaar_base * 1000,
      demo_pressure: d.demo_total / d.aadhaar_base * 1000,
      age_mismatch: d.age_mismatch_score,
      aadhaar_base: d.aadhaar_base
    }));
};

export const getStateTypologyMatrix = () => {
  const matrix = new Map<string, Map<string, number>>();
  
  mockDistrictData.forEach(d => {
    if (!d.cluster_name) return;
    
    if (!matrix.has(d.state_canonical)) {
      matrix.set(d.state_canonical, new Map());
    }
    const stateMap = matrix.get(d.state_canonical)!;
    stateMap.set(d.cluster_name, (stateMap.get(d.cluster_name) || 0) + 1);
  });
  
  // Get top 10 states by total observations
  const stateTotals = Array.from(matrix.entries())
    .map(([state, typMap]) => ({
      state,
      total: Array.from(typMap.values()).reduce((a, b) => a + b, 0)
    }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 10);
  
  return stateTotals.map(({ state }) => {
    const typMap = matrix.get(state)!;
    return {
      state,
      "Biometric-Stress Districts": typMap.get("Biometric-Stress Districts") || 0,
      "Documentation-Heavy Districts": typMap.get("Documentation-Heavy Districts") || 0,
      "Transition-Backlog Districts": typMap.get("Transition-Backlog Districts") || 0,
      "Low-Friction Stable Districts": typMap.get("Low-Friction Stable Districts") || 0,
      "High-Volume Urban Districts": typMap.get("High-Volume Urban Districts") || 0
    };
  });
};
