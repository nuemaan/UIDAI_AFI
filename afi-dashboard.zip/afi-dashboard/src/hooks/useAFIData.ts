import { useQuery } from "@tanstack/react-query";
import {
  fetchDistrictData,
  getStateSummary,
  getTypologySummary,
  getDistrictHotspots,
  getAFIDistribution,
  getNationalStats,
  getDecompositionData,
  getStateTypologyMatrix,
  DistrictData,
} from "@/services/afiDataService";
import {
  mockDistrictData,
  getStateSummary as getMockStateSummary,
  getTypologySummary as getMockTypologySummary,
  getDistrictHotspots as getMockDistrictHotspots,
  getAFIDistribution as getMockAFIDistribution,
  getNationalStats as getMockNationalStats,
  getDecompositionData as getMockDecompositionData,
  getStateTypologyMatrix as getMockStateTypologyMatrix,
} from "@/data/mockData";

export const useAFIData = () => {
  const {
    data: dbResult,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ["district-afi-data"],
    queryFn: fetchDistrictData,
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 30 * 60 * 1000, // Keep in cache for 30 minutes
  });

  // Extract data from result
  const dbData = dbResult?.data;
  const totalCount = dbResult?.totalCount || 0;
  const isPartialData = dbResult?.isPartial || false;

  // Log data loading status
  console.log(`AFI Data: ${dbData?.length || 0} of ${totalCount} records loaded, isLoading: ${isLoading}, partial: ${isPartialData}`);

  // Force mock data for performance - database has too many records
  const hasRealData = false;
  const useMockData = true;
  
  const rawData: DistrictData[] = mockDistrictData.map((d, i) => ({
    ...d,
    id: `mock-${i}`,
  }));

  return {
    rawData,
    isLoading,
    error,
    refetch,
    hasRealData,
    useMockData,
    dataSource: "mock",
    totalCount,
    isPartialData: false,
    loadedCount: rawData.length,
    
    // Computed data
    stateSummary: hasRealData ? getStateSummary(rawData) : getMockStateSummary(),
    typologySummary: hasRealData ? getTypologySummary(rawData) : getMockTypologySummary(),
    districtHotspots: (limit?: number) =>
      hasRealData
        ? getDistrictHotspots(rawData, limit)
        : getMockDistrictHotspots(limit),
    afiDistribution: hasRealData ? getAFIDistribution(rawData) : getMockAFIDistribution(),
    nationalStats: hasRealData ? getNationalStats(rawData) : getMockNationalStats(),
    decompositionData: hasRealData ? getDecompositionData(rawData) : getMockDecompositionData(),
    stateTypologyMatrix: hasRealData
      ? getStateTypologyMatrix(rawData)
      : getMockStateTypologyMatrix(),
  };
};
